class WithoutVarags{  
   
 public int add(int n,int i)
 {
	return n+i;
 }
  
 public static void main(String args[]){  
  
  WithoutVarags obj=new WithoutVarags ();
  System.out.println(obj.add(4,1));
 
 }   
}  