class RCB
{
static void players()
{
 System.out.println("shetty");
 System.out.println("prathii");
}

static void players(String name)
{
 System.out.println(name);
 System.out.println("Pratheeka shetty");
 System.out.println("Jayanthi shetty");
}
static void players(int num)
{
 
 System.out.println(num);
 System.out.println("praneeth shetty");
}
static byte noBy(){
	return 8;
}
}
