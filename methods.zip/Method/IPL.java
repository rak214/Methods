class IPL
{
public static void main(String []args)
{
 RCB.players();
 RCB.players("Suresh shetty");
RCB.players("23");

 byte res=RCB.noBy();
System.out.println(res);
}




}