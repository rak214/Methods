class Adder
 {  
  static int add(int x, int y)
   {
      return x+y;
   }  
  static double add(double x, double y)
   {
   return x+y;
   }  
}  